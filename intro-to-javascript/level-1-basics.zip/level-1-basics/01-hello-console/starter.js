// =============================================================
// Level 1 · Task 1 — Hello, Console
// =============================================================
// Lines that start with // are COMMENTS. JavaScript ignores them.
// We use them to leave notes for humans.
//
// Here's an example. Save the file, refresh the page, and look
// at the Console panel on the right:

console.log("I am running!");

// Now it's your turn. Write each line of code under its TODO.


// TODO 1: Log the exact text "Hello, JavaScript!"


// TODO 2: Log your name. Text always goes inside quotes: "Sara"


// TODO 3: Log the number 7. Numbers do NOT get quotes.


// TODO 4: Log the number of hours in a week.
//         Don't work it out yourself. Write 7 * 24 and let JS do it.


// TODO 5: Log typeof "hello"   then, on a new line, log typeof 42


// TODO 6: Log two values in ONE console.log, separated by a comma.
//         Example: console.log("Age:", 20)

